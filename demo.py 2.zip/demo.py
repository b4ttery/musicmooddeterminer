import lyricsgenius
artist = input("Enter artist:") 
song = input("Enter Song Name:")
genius = lyricsgenius.Genius("j-cudRyJRuE-qo9xLK7vjZg8WkFFUGj7tVQ6q3yBxn7UxmuHQ6M1M372cM498Pkw")
artist = genius.search_artist(artist, max_songs=0, sort="title")
song = artist.song(song)
song.save_lyrics(filename="lyrics", extension="txt", overwrite=True, verbose=False)


goodwords = ["happy","love","callin'","good","dance","god","thank","promiscuous","fun","beautiful","entrusted","foreign","guap","excitin","exciting","diamonds","thank god","roll","opps","shawty","blowin'","runnin","party","sunflower","hater","drippin'","swaggin'","popping","Poppin'","dough"]
badwords = ["red-handed","creeping","lost","alone","killer","It's the pain pills","downfall","confusion","suffer","bleed","beat", "hate you","remember","dying","dyin'","cruel","unkind","sad","crying","leave","abuse"]
file = open('lyrics.txt')
s=" "
happy = 0
sad = 0
L= file.readlines()

for i in L:
        L2=i.split()

for j in goodwords:
 for x in L2:
     if (j == x):
      happy = happy + 1
     
for y in badwords:
    for a in L2:
     if (y == a):
      sad = sad + 1
      
      
if happy > sad:
    print("This song is happy")
if sad > happy:
    print("This song is sad")
